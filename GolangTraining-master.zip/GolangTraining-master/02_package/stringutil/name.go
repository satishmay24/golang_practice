package stringutil

// MyName will be exported because it starts with a capital letter.
var MyName = "Todd"
