package winniepooh

// MyName will be exported because it starts with a capital letter.
var BearName = "Pooh"
