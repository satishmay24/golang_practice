package main

import "fmt"

func main() {
	name := "Todd"
	fmt.Println("Hello", name)
}
