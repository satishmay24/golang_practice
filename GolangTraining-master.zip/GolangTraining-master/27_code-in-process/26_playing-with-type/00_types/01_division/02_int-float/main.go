package main

import "fmt"

func main() {
	fmt.Println(32 / 3.74)
}
