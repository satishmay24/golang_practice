package main

import "fmt"

func main() {
	var answer int
	answer = 32 / 3.74
	fmt.Println(answer)
}
