package main

import (
	"fmt"
	"os"
)

func main() {
	entry := os.Args[1]
	fmt.Println(entry)
}

/*
step 1:
go install

step 2 - from terminal:
programName arguments

*/
