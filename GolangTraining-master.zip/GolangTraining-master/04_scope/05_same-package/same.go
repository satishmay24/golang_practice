package main

var x = 7
