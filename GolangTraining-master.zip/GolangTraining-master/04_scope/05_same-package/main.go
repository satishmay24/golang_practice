package main

import "fmt"

func main() {
	fmt.Println(x)
}

// IMPORTANT
// to run this code:
// go run *.go
// ---- OR ----
// go build
//./05_same-package
